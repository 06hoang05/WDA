﻿using Microsoft.EntityFrameworkCore;

namespace ASP_Net.Models
{
    public class HR_ManageContext:DbContext
    {
        public DbSet<Department> Department { get; set; }
        public DbSet<Employee> Employee { get; set; }

        public HR_ManageContext(DbContextOptions<HR_ManageContext> options) : base(options)
        {
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
      => optionsBuilder.UseSqlServer(GetConnectionString());
        private string? GetConnectionString()
        {
            IConfiguration configuration = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json", true, true).Build();
            return configuration["ConnectionStrings:DBDefault"];
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Department>().HasData(
                   new Department { DepartmentID = 1, DepartmentName = "Accounting Department" },
                   new Department { DepartmentID = 2, DepartmentName = "IT Department" },
                   new Department { DepartmentID = 3, DepartmentName = "Makerting Department" }
               );
        }
    }
}
