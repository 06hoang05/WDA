﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ASP_Net.Models
{
    [Table("Employee_Tbl")]
    public class Employee
    {
        
            [Key]
            [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
            public int EmployeeID { get; set; }
            public string? EmployeeName { get; set; }
            public int DepartmentID { get; set; }
            [ForeignKey("DepartmentID")]
            public Department? department { get; set; }
        
    }
}
