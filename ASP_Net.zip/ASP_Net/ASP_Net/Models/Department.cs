﻿using static ASP_Net.Models.Employee;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ASP_Net.Models
{
    [Table("Department_Tbl")]
    public class Department
    {
        
            [Key]
            [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
            public int DepartmentID { get; set; }
            [Required]
            public string? DepartmentName { get; set; }

            public ICollection<Employee>? Employees { get; set; }
        
    }
}
