﻿using ASP_Net.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ASP_Net.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly HR_ManageContext context;
        public DepartmentController(HR_ManageContext context)
        {
            this.context = context;
        }
        // GET: DepartmentController
        public ActionResult Index()
        {
            var listDepartment = context.Department.ToList();

            return View(listDepartment);
        }

        // GET: DepartmentController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: DepartmentController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: DepartmentController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Department department)
        {
            if (ModelState.IsValid)
            {
                context.Department.Add(department);
                context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        // GET: DepartmentController/Edit/5
        public ActionResult Edit(int id)
        {
            var departmentGetById = context.Department.FirstOrDefault(x => x.DepartmentID == id);
            if (departmentGetById == null) return NotFound();
            return View(departmentGetById);
        }

        // POST: DepartmentController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Department department)
        {
            if (ModelState.IsValid)
            {
                context.Department.Update(department);
                context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        // GET: DepartmentController/Delete/5
        public ActionResult Delete(int id)
        {
            var departmentGetById = context.Department.FirstOrDefault(x => x.DepartmentID == id);
            context.Department.Remove(departmentGetById);
            context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        // POST: DepartmentController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        public ActionResult Reporting(int id)
        {

            var query = context.Employee.ToList().Where(x => x.DepartmentID == id);
            var departmentGetById = context.Department.FirstOrDefault(x => x.DepartmentID == id);
            ViewBag.department = departmentGetById;
            //if (query.IsNullOrEmpty()) return NotFound();
            return View(query);
        }

        //create employee
        public ActionResult Employee()
        {
            var listDepartment = context.Department.ToList();
            // Chuyển đổi thành SelectListItem
            var departmentSelectList = listDepartment.Select(d => new SelectListItem
            {
                Value = d.DepartmentID.ToString(), // Giá trị khi người dùng chọn (mã phòng ban)
                Text = d.DepartmentName // Tên hiển thị cho người dùng (tên phòng ban)
            }).ToList();

            ViewBag.departments = departmentSelectList;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Employee(Employee employee)
        {
            if (ModelState.IsValid)
            {
                context.Employee.Add(employee);
                context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View();
        }
    }
}
